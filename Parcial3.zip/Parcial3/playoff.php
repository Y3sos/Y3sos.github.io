<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>NBA PLAYOFF</title>
  <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="icon"  href="imagenes/logo.png">
</head>
<body>
  <header>
    <div class="menu">
  <ul>
    <li><a href="inicio.php">Noticias de ultima hora</a></li>
    <li><a href="playoff.php">PLAYOFFS</a></li>
    <li><a href="anillos.php">Anillos entregados</a></li>
    <li><a href="index.php">Cerrar secion</a></li>

  </ul>
</div>
  </header>

  <main>
    <center>
    <h1>PLAYOFFS</h1>
    </center>
  </main>
        <center><h1>Playoffs de 2022-2023</h1></center>
    <br>
    <br>
    <center>
  <img src="imagenes/p1.png" height="100%" width="100%">
</center>

<br>
        <center><h1>Playoffs de 2020-2021</h1></center>
<center>
  <img src="imagenes/p2.png" height="100%" width="100%">
</center>


</body>
</html>