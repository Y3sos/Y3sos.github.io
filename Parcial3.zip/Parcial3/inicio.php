<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>NBA Noticias</title>
  <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="icon"  href="imagenes/logo.png">
</head>
<body>
  <header>
    <div class="menu">
  <ul>
    <li><a href="inicio.php">Noticias de ultima hora</a></li>
    <li><a href="playoff.php">PLAYOFFS</a></li>
    <li><a href="anillos.php">Anillos entregados</a></li>
    <li><a href="index.php">Cerrar secion</a></li>

  </ul>
</div>
  </header>

  <main>
    <center>
    <h1>Bienvenido a nuestra pagina de noticias NBA</h1>
    <p>¡Encuentra aquí las mas recientes noticias sobre la NBA!</p>
    </center>
  </main>
        <center><h1>Noticias de ultima hora</h1></center>
<section id="noticias" class="noticias">
      <div class="noticia">
        <img src="imagenes/n1.png" height="40%" width="40%">
        <center>
        <h4>La superación personal de Jokic: de pesar 136 kilos y una adicción a los refrescos a hacer historia con los Nuggets en la NBA</h4>
        <p>Tras tres temporadas dominando la Liga norteamericana, el pívot serbio logra su primer anillo con los de Colorado.
 La historia de superación de Ihor: el erasmus ucraniano que huyó de la guerra y ahora es campeón de España.</p>
 </center>
        <input type="hidden" name="noticias" value="basquetball - ultima hora">
  <input type="hidden" name="precio" value="200">
      </div>
      <div class="noticia">
        <img src="imagenes/n2.png" height="40%" width="40%">
        <center>
        <h4>La sorprendente reacción de Jokic al mirar si Djokovic le había felicitado por ganar la NBA: "Oh, no, mi teléfono..."</h4>
        <p>El serbio, MVP de las finales, fue preguntado por su compatriota en la rueda de prensa posterior.
Denver entra en el Olimpo de la NBA: primer anillo en sus primeras finales tras tumbar a Miami.</p>
        <input type="hidden" name="producto" value="Zapatos de basquetball - Rojo/Blanco">
  <input type="hidden" name="precio" value="200">
      </div>
      <div class="noticia">
        <img src="imagenes/n3.png" height="40%" width="40%">
        <center>
        <h4>Conor McGregor manda al hospital a la mascota de los Miami Heat tras dos puñetazos</h4>
        <p>Lo que se supone que era una broma acabó en urgencias.
 Se reabre la investigación por la supuesta agresión sexual de McGregor a una mujer irlandesa en Ibiza.</p>
</center>
        <input type="hidden" name="producto" value="Zapatos de basquetball - Rojo/Blanco">
  <input type="hidden" name="precio" value="200">
      </div>
      <div class="noticia">
        <img src="imagenes/n4.png" height="40%" width="40%">
        <center>
        <h4>Los Heat conquistan Denver y dan emoción a las Finales de la NBA</h4>
        <p>Miami se llevan la victoria ante los Nuggets (111-108) y empatan la serie antes de jugar en casa.</p>
        <input type="hidden" name="producto" value="Zapatos de basquetball - Rojo/Blanco">
        </center>
  <input type="hidden" name="precio" value="200">
      </div>
      <div class="noticia">
        <img src="imagenes/n5.png" height="40%" width="40%">
        <center>
        <h4>El traspaso que puede poner patas arriba la NBA: LeBron jugaría con Irving y Doncic</h4>
        <p>El de Dallas Mavericks se ha reunido con su amigo para que deje los Lakers y se mude a Texas.
Un hombre es detenido por masturbarse junto a una joven durante la celebración del Barça femenino.</p>
        <input type="hidden" name="producto" value="Zapatos de basquetball - Rojo/Blanco">
      </center>
  <input type="hidden" name="precio" value="200">
      </div>
      <div class="noticia">
        <img src="imagenes/n6.png" height="40%" width="40%">
        <center>
        <h4>Jimmy Butler cumple su promesa y guía a los Heat a las Finales de la NBA</h4>
        <p>Miami Heat arrasó a los Cetlcis (103-84) en su cancha en el séptimo partido de la final del Este.
 Los Nuggets cambian su historia en la NBA: a la final tras borrar a los Lakers de un LeBron que deja entrever su retirada.</p>
        <input type="hidden" name="producto" value="Zapatos de basquetball - Rojo/Blanco">
        </center>
  <input type="hidden" name="precio" value="200">
        </div>
    </section>
</body>
</html>
