<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>NBA Anillos</title>
  <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="icon"  href="imagenes/logo.png">
</head>
<body>
  <header>
    <div class="menu">
  <ul>
    <li><a href="inicio.php">Noticias de ultima hora</a></li>
    <li><a href="playoff.php">PLAYOFFS</a></li>
    <li><a href="anillos.php">Anillos entregados</a></li>
    <li><a href="index.php">Cerrar secion</a></li>
  </ul>
</div>
  </header>

  <main>
    <center>
    <h1>EQUIPOS QUE GANARON ANILLOS</h1>
    </center>
  </main>
        <center><h1>Los Angeles Lakers</h1></center>
    <br>
    <br>
    <center>
  <img src="imagenes/e1.png" height="20%" width="20%">
  <p>17 anillos</p>
</center>

<br>
        <center><h1>Golden State Warriors</h1></center>
<center>
  <img src="imagenes/e2.png" height="11%" width="11%">
  <p>7 anillos</p>

</center>

<br>
        <center><h1>Chicago Bulls</h1></center>
<center>
  <img src="imagenes/e3.png" height="11%" width="11%">
    <p>6 anillos</p>
</center>

<br>
        <center><h1>San Antonio Spurs</h1></center>
<center>
  <img src="imagenes/e4.png" height="11%" width="11%">
      <p>5 anillos</p>

</center>

</body>
</html>